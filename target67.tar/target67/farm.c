/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_395()
{
    return 2503131992U;
}

unsigned addval_347(unsigned x)
{
    return x + 1477771759U;
}

void setval_323(unsigned *p)
{
    *p = 3281279152U;
}

unsigned getval_272()
{
    return 3284633928U;
}

void setval_214(unsigned *p)
{
    *p = 3638468057U;
}

unsigned getval_294()
{
    return 3347662968U;
}

unsigned addval_389(unsigned x)
{
    return x + 2462550344U;
}

unsigned addval_267(unsigned x)
{
    return x + 3351742792U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_329(unsigned x)
{
    return x + 3682128265U;
}

void setval_187(unsigned *p)
{
    *p = 2429649322U;
}

unsigned getval_465()
{
    return 3221803417U;
}

void setval_151(unsigned *p)
{
    *p = 2425409160U;
}

unsigned getval_421()
{
    return 2497743176U;
}

void setval_402(unsigned *p)
{
    *p = 3524841097U;
}

unsigned getval_322()
{
    return 3677933185U;
}

void setval_426(unsigned *p)
{
    *p = 3221279113U;
}

unsigned addval_225(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_495(unsigned x)
{
    return x + 3229142665U;
}

unsigned addval_333(unsigned x)
{
    return x + 3221803401U;
}

unsigned getval_179()
{
    return 3380924041U;
}

unsigned addval_218(unsigned x)
{
    return x + 3676361097U;
}

unsigned addval_491(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_216()
{
    return 3374891657U;
}

unsigned getval_480()
{
    return 3529560457U;
}

unsigned getval_119()
{
    return 3222848137U;
}

unsigned addval_295(unsigned x)
{
    return x + 3372794505U;
}

void setval_308(unsigned *p)
{
    *p = 3285092730U;
}

unsigned getval_357()
{
    return 3767224387U;
}

unsigned addval_143(unsigned x)
{
    return x + 2430601544U;
}

void setval_462(unsigned *p)
{
    *p = 2425475465U;
}

unsigned getval_353()
{
    return 2425406091U;
}

unsigned getval_219()
{
    return 2425409225U;
}

unsigned getval_264()
{
    return 2026095241U;
}

void setval_458(unsigned *p)
{
    *p = 3534013065U;
}

void setval_373(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_100(unsigned x)
{
    return x + 3222848137U;
}

unsigned getval_318()
{
    return 3286273352U;
}

unsigned getval_244()
{
    return 2428676409U;
}

unsigned getval_438()
{
    return 3286272328U;
}

unsigned getval_235()
{
    return 3281047179U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
